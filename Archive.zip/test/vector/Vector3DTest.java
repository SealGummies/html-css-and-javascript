package vector;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Test class for the Vector3D class.
 */
public class Vector3DTest {

  private Vector3D vector;

  @Before
  public void setUp() {
    vector = new Vector3D(3.0, 2.0, 1.0);
  }

  @Test
  public void testCreateVectorWithArray() {
    double[] values = {1.0, 2.0, 3.0};
    Vector3D vector = new Vector3D(values);
    assertEquals(1.0, vector.getX(), 0.0);
    assertEquals(2.0, vector.getY(), 0.0);
    assertEquals(3.0, vector.getZ(), 0.0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateVectorWithArrayWithWrongSize() {
    double[] values = {1.0, 2.0};
    new Vector3D(values);
  }

  @Test
  public void getX() {
    assertEquals(3.0, vector.getX(), 0.0);
  }

  @Test
  public void getZ() {
    assertEquals(1.0, vector.getZ(), 0.0);
  }

  @Test
  public void getMagnitude() {
    assertEquals(3.7416573867739413, vector.getMagnitude(), 0.0);
  }

  @Test
  public void normalize() {
    Vector3D normalizedVector = vector.normalize();
    assertEquals(0.80, normalizedVector.getX(), 0.01);
    assertEquals(0.53, normalizedVector.getY(), 0.01);
    assertEquals(0.27, normalizedVector.getZ(), 0.01);
  }

  @Test(expected = IllegalStateException.class)
  public void testNormalizeWithZeroVector() {
    Vector3D zeroVector = new Vector3D(0.0, 0.0, 0.0);
    zeroVector.normalize();
  }

  @Test
  public void testToString() {
    assertEquals("[3.00, 2.00, 1.00]", vector.toString());
  }
}