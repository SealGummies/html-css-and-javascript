package vector;

/**
 * Class to represent a 3D vector.
 */
public class Vector3D {
  private final double directionX;
  private final double directionY;
  private final double directionZ;

  /**
   * A constructor that takes in an array of doubles.
   *
   * @param array Array with the values of the vector.
   */
  public Vector3D(double[] array) {
    if (array.length != 3) {
      throw new IllegalArgumentException("Array must have 3 elements");
    }
    this.directionX = array[0];
    this.directionY = array[1];
    this.directionZ = array[2];
  }

  /**
   * A constructor that takes in x, y, z components of the vector.
   * Each parameter is of type double.
   *
   * @param x The x value of the vector.
   * @param y The y value of the vector.
   * @param z The z value of the vector.
   */
  public Vector3D(double x, double y, double z) {
    this.directionX = x;
    this.directionY = y;
    this.directionZ = z;
  }

  /**
   * A method to get the direction of the vector in the x direction.
   *
   * @return The x value of the vector.
   */
  public double getX() {
    return this.directionX;
  }

  /**
   * A method to get the direction of the vector in the y direction.
   *
   * @return The y value of the vector.
   */
  public double getY() {
    return this.directionY;
  }

  /**
   * A method to get the direction of the vector in the z direction.
   *
   * @return The z value of the vector.
   */
  public double getZ() {
    return this.directionZ;
  }

  /**
   * A method to get the magnitude of the vector.
   *
   * @return The magnitude of the vector.
   */
  public double getMagnitude() {
    return Math.sqrt(
        Math.pow(this.directionX, 2) + Math.pow(this.directionY, 2) + Math.pow(this.directionZ, 2));
  }

  /**
   * A method that returns a normalized version of this vector.
   * It should throw an IllegalStateException if this operation cannot be completed.
   *
   * @return A normalized version of the vector.
   */
  public Vector3D normalize() {
    double magnitude = this.getMagnitude();
    if (magnitude == 0) {
      throw new IllegalStateException("Cannot normalize a vector with magnitude 0");
    }
    return new Vector3D(this.directionX / magnitude, this.directionY / magnitude,
        this.directionZ / magnitude);
  }

  /**
   * A toString() method that returns a string that describes this vector.
   * This string should be of the form “[x, y, z]” replacing the letters with their values.
   * Each component should be formatted to round to exactly two decimal places.
   *
   * @return A string that describes this vector.
   */
  @Override
  public String toString() {
    return "[" + String.format("%.2f", this.directionX) + ", "
        + String.format("%.2f", this.directionY)
        + ", " + String.format("%.2f", this.directionZ) + "]";
  }
}