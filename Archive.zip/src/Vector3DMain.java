import vector.Vector3D;

/**
 * Main class to test the Vector3D class.
 */
public class Vector3DMain {
  /**
   * Main method to test the Vector3D class.
   *
   * @param args They are going to be ignored
   */
  public static void main(String[] args) {
    Vector3D xyzVector = new Vector3D(3.0, 2.0, 1.0);
    System.out.println("Vector: " + xyzVector);
    System.out.println("Magnitude: " + xyzVector.getMagnitude());
    System.out.println("Normalized: " + xyzVector.normalize());

    double[] values = {1.0, 2.0, 3.0};
    Vector3D vector = new Vector3D(values);
    System.out.println("Vector: " + vector);
    System.out.println("Magnitude: " + vector.getMagnitude());
    System.out.println("Normalized: " + vector.normalize());

    try {
      double[] values2 = {1.0, 2.0};
      new Vector3D(values2);
    } catch (IllegalArgumentException e) {
      System.out.println("Exception thrown with two dimensional array");
    }

    try {
      double[] values3 = {1.0, 2.0, 3.0, 4.0};
      new Vector3D(values3);
    } catch (IllegalArgumentException e) {
      System.out.println("Exception thrown with four dimensional array");
    }

    try {
      Vector3D zeroVector = new Vector3D(0.0, 0.0, 0.0);
      System.out.println("Vector: " + zeroVector);
      System.out.println("Magnitude: " + zeroVector.getMagnitude());
      System.out.println("Normalized: " + zeroVector.normalize());
    } catch (IllegalStateException e) {
      System.out.println("Exception thrown with zero vector");
    }


  }
}